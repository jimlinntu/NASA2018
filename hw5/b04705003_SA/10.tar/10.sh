#!/usr/bin/env bash
sudo mkdir /repo 2>/dev/null
# Append [nasa-repo] at the end of pacman.conf
if [[ $(grep -c 'nasa-repo' /etc/pacman.conf ) == 0 ]]; then
	printf "[nasa-repo]\nSigLevel = TrustAll\nServer = file:///repo\n" | \
		sudo tee -a /etc/pacman.conf 1>/dev/null
fi	
# Create nasa-repo.db.tar.gz. 
# Note that sudo-oasis-0.1-1-any.pkg.tar.xz.sig must be in the same directory
sudo repo-add /repo/nasa-repo.db.tar.gz sudo-oasis-0.1-1-any.pkg.tar.xz
# Add the key to pacman keyring
sudo pacman-key --add b04705003.pub
# Move package tarball under /repo/ folder
sudo cp sudo-oasis-0.1-1-any.pkg.tar.xz /repo/
